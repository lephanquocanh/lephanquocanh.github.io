<meta name="description" content="Website chống lừa đảo Check Scam kiểm tra, lưu trữ, tố cáo info kẻ Scam trên mxh. <?=$site_tenweb;?> giúp bạn an toàn trong mọi giao dịch online, tránh khỏi những rủi do mất tiền không đáng có" />
<meta property="og:locale" content="vi_VN" />
<meta property="og:type" content="website" />
<meta property="og:title" content="[ <?=$site_tenweb;?> ] Hệ thống Kiểm tra, Tố cáo thông tin lừa đảo" />
<meta property="og:description" content="Website chống lừa đảo Check Scam kiểm tra, lưu trữ, tố cáo kẻ Scam trên mxh. <?=$site_tenweb;?> giúp bạn tránh khỏi những rủi do trong mọi giao dịch online" />
<meta property="og:url" content="https://<?=$site_tenweb;?>" />
<meta property="og:site_name" content="[ <?=$site_tenweb;?> ] Hệ thống Kiểm tra, Tố cáo thông tin lừa đảo" />
<meta property="og:image" content="https://i.imgur.com/xtNz5NM.png" />
<meta property="og:image:width" content="1386" />
<meta property="og:image:height" content="762" />
<meta property="og:image:type" content="image/png" />
<meta name="twitter:card" content="summary_large_image" />

<link href='https://ajax.googleapis.com' rel='dns-prefetch' />
<link href='https://fonts.googleapis.com' rel='dns-prefetch' />
<link rel='dns-prefetch' href='https://cdn.jsdelivr.net'/>
<link rel='dns-prefetch' href='https://i.imgur.com'/>
<link rel='dns-prefetch' href='https://facebook.com'/>
<link rel='dns-prefetch' href='https://mmovip.me' />
<link rel='dns-prefetch' href='https://cloudflare.com' />

