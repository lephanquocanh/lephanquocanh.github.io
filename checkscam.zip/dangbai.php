<!-- Fake By Trinh Ngoc Minh - 0334955115 -->
<?php include 'config.php'; ?>
<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
<link rel='stylesheet' id='h-style-css' href='assets/style.css?ver=8.5' type='text/css' media='all' />
<link type="text/css" href="assets/font.all.min.css" rel="stylesheet">
<meta name='robots' content='index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1' />
<title>[ <?=$site_tenweb;?> ] Hệ thống Kiểm tra, Tố cáo thông tin lừa đảo</title>
<?php include 'meta.php'; ?>


<script type="09953b84707dccdc6e3a3fde-text/javascript">
      window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.1.0\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.1.0\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/checkscam.info\/wp-includes\/js\/wp-emoji-release.min.js?ver=5.8.3"}};
      !function(e,a,t){var n,r,o,i=a.createElement("canvas"),p=i.getContext&&i.getContext("2d");function s(e,t){var a=String.fromCharCode;p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,e),0,0);e=i.toDataURL();return p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,t),0,0),e===i.toDataURL()}function c(e){var t=a.createElement("script");t.src=e,t.defer=t.type="text/javascript",a.getElementsByTagName("head")[0].appendChild(t)}for(o=Array("flag","emoji"),t.supports={everything:!0,everythingExceptFlag:!0},r=0;r<o.length;r++)t.supports[o[r]]=function(e){if(!p||!p.fillText)return!1;switch(p.textBaseline="top",p.font="600 32px Arial",e){case"flag":return s([127987,65039,8205,9895,65039],[127987,65039,8203,9895,65039])?!1:!s([55356,56826,55356,56819],[55356,56826,8203,55356,56819])&&!s([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]);case"emoji":return!s([10084,65039,8205,55357,56613],[10084,65039,8203,55357,56613])}return!1}(o[r]),t.supports.everything=t.supports.everything&&t.supports[o[r]],"flag"!==o[r]&&(t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&t.supports[o[r]]);t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&!t.supports.flag,t.DOMReady=!1,t.readyCallback=function(){t.DOMReady=!0},t.supports.everything||(n=function(){t.readyCallback()},a.addEventListener?(a.addEventListener("DOMContentLoaded",n,!1),e.addEventListener("load",n,!1)):(e.attachEvent("onload",n),a.attachEvent("onreadystatechange",function(){"complete"===a.readyState&&t.readyCallback()})),(n=t.source||{}).concatemoji?c(n.concatemoji):n.wpemoji&&n.twemoji&&(c(n.twemoji),c(n.wpemoji)))}(window,document,window._wpemojiSettings);
    </script>
<style type="text/css">
img.wp-smiley,
img.emoji {
  display: inline !important;
  border: none !important;
  box-shadow: none !important;
  height: 1em !important;
  width: 1em !important;
  margin: 0 .07em !important;
  vertical-align: -0.1em !important;
  background: none !important;
  padding: 0 !important;
}
#mn #tgn {
    width: 50px;
    height: 50px;
    background-position: 0 0;
    float: left;
    cursor: pointer;
    background:url(https://uploadfree.pw/theme-checkscam.info/images/i.png) no-repeat;
    display: inline-block;
}
</style>
<link rel='stylesheet' id='wp-block-library-css' href='assets/style.min.css?ver=5.8.3' type='text/css' media='all' />
<script type="09953b84707dccdc6e3a3fde-text/javascript">
            window._nslDOMReady = function (callback) {
                if ( document.readyState === "complete" || document.readyState === "interactive" ) {
                    callback();
                } else {
                    document.addEventListener( "DOMContentLoaded", callback );
                }
            };
            </script><script type="09953b84707dccdc6e3a3fde-text/javascript" src='assets/jquery.min.js?ver=3.6.0' id='jquery-core-js'></script>
<script type="09953b84707dccdc6e3a3fde-text/javascript" src='assets/jquery-migrate.min.js?ver=3.3.2' id='jquery-migrate-js'></script>
<meta name="generator" content="WordPress 5.8.3" />
<style type="text/css">.recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;}</style><link rel="icon" href="https://uploadfree.pw/theme-checkscam.info/images/cropped-Logo-vuong-32x32.png" sizes="32x32" />
<link rel="icon" href="https://uploadfree.pw/theme-checkscam.info/images/cropped-Logo-vuong-192x192.png" sizes="192x192" />
<link rel="apple-touch-icon" href="https://uploadfree.pw/theme-checkscam.info/images/cropped-Logo-vuong-180x180.png" />
<meta name="msapplication-TileImage" content="https://uploadfree.pw/theme-checkscam.info/images/cropped-Logo-vuong-270x270.png" />
<style type="text/css">div.nsl-container[data-align="left"] {
    text-align: left;
}

div.nsl-container[data-align="center"] {
    text-align: center;
}

div.nsl-container[data-align="right"] {
    text-align: right;
}


div.nsl-container .nsl-container-buttons a {
    text-decoration: none !important;
    box-shadow: none !important;
    border: 0;
}

div.nsl-container .nsl-container-buttons {
    display: flex;
    padding: 5px 0;
}

div.nsl-container.nsl-container-block .nsl-container-buttons {
    display: inline-grid;
    grid-template-columns: minmax(145px, auto);
}

div.nsl-container-block-fullwidth .nsl-container-buttons {
    flex-flow: column;
    align-items: center;
}

div.nsl-container-block-fullwidth .nsl-container-buttons a,
div.nsl-container-block .nsl-container-buttons a {
    flex: 1 1 auto;
    display: block;
    margin: 5px 0;
    width: 100%;
}

div.nsl-container-inline {
    margin: -5px;
    text-align: left;
}

div.nsl-container-inline .nsl-container-buttons {
    justify-content: center;
    flex-wrap: wrap;
}

div.nsl-container-inline .nsl-container-buttons a {
    margin: 5px;
    display: inline-block;
}

div.nsl-container-grid .nsl-container-buttons {
    flex-flow: row;
    align-items: center;
    flex-wrap: wrap;
}

div.nsl-container-grid .nsl-container-buttons a {
    flex: 1 1 auto;
    display: block;
    margin: 5px;
    max-width: 280px;
    width: 100%;
}

@media only screen and (min-width: 650px) {
    div.nsl-container-grid .nsl-container-buttons a {
        width: auto;
    }
}

div.nsl-container .nsl-button {
    cursor: pointer;
    vertical-align: top;
    border-radius: 4px;
}

div.nsl-container .nsl-button-default {
    color: #fff;
    display: flex;
}

div.nsl-container .nsl-button-icon {
    display: inline-block;
}

div.nsl-container .nsl-button-svg-container {
    flex: 0 0 auto;
    padding: 8px;
    display: flex;
    align-items: center;
}

div.nsl-container svg {
    height: 24px;
    width: 24px;
    vertical-align: top;
}

div.nsl-container .nsl-button-default div.nsl-button-label-container {
    margin: 0 24px 0 12px;
    padding: 10px 0;
    font-family: Helvetica, Arial, sans-serif;
    font-size: 16px;
    line-height: 20px;
    letter-spacing: .25px;
    overflow: hidden;
    text-align: center;
    text-overflow: clip;
    white-space: nowrap;
    flex: 1 1 auto;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    text-transform: none;
    display: inline-block;
}

div.nsl-container .nsl-button-google[data-skin="dark"] .nsl-button-svg-container {
    margin: 1px;
    padding: 7px;
    border-radius: 3px;
    background: #fff;
}

div.nsl-container .nsl-button-google[data-skin="light"] {
    border-radius: 1px;
    box-shadow: 0 1px 5px 0 rgba(0, 0, 0, .25);
    color: RGBA(0, 0, 0, 0.54);
}

div.nsl-container .nsl-button-apple .nsl-button-svg-container {
    padding: 0 6px;
}

div.nsl-container .nsl-button-apple .nsl-button-svg-container svg {
    height: 40px;
    width: auto;
}

div.nsl-container .nsl-button-apple[data-skin="light"] {
    color: #000;
    box-shadow: 0 0 0 1px #000;
}

div.nsl-container .nsl-button-facebook[data-skin="white"] {
    color: #000;
    box-shadow: inset 0 0 0 1px #000;
}

div.nsl-container .nsl-button-facebook[data-skin="light"] {
    color: #1877F2;
    box-shadow: inset 0 0 0 1px #1877F2;
}

div.nsl-container .nsl-button-apple div.nsl-button-label-container {
    font-size: 17px;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol";
}

.nsl-clear {
    clear: both;
}

.nsl-container {
    clear: both;
}

/*Button align start*/

div.nsl-container-inline[data-align="left"] .nsl-container-buttons {
    justify-content: flex-start;
}

div.nsl-container-inline[data-align="center"] .nsl-container-buttons {
    justify-content: center;
}

div.nsl-container-inline[data-align="right"] .nsl-container-buttons {
    justify-content: flex-end;
}


div.nsl-container-grid[data-align="left"] .nsl-container-buttons {
    justify-content: flex-start;
}

div.nsl-container-grid[data-align="center"] .nsl-container-buttons {
    justify-content: center;
}

div.nsl-container-grid[data-align="right"] .nsl-container-buttons {
    justify-content: flex-end;
}

div.nsl-container-grid[data-align="space-around"] .nsl-container-buttons {
    justify-content: space-around;
}

div.nsl-container-grid[data-align="space-between"] .nsl-container-buttons {
    justify-content: space-between;
}

/* Button align end*/

/* Redirect */

#nsl-redirect-overlay {
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    position: fixed;
    z-index: 1000000;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    backdrop-filter: blur(1px);
    background-color: RGBA(0, 0, 0, .32);;
}

#nsl-redirect-overlay-container{
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    background-color: white;
    padding: 30px;
    border-radius: 10px;
}

#nsl-redirect-overlay-spinner {
    content: '';
    display: block;
    margin: 20px 0;
    border: 9px solid RGBA(0, 0, 0, .6);
    border-top: 9px solid #fff;
    border-radius: 50%;
    box-shadow: inset 0 0 0 1px RGBA(0, 0, 0, .6), 0 0 0 1px RGBA(0, 0, 0, .6);
    width: 40px;
    height: 40px;
    animation: nsl-loader-spin 2s linear infinite;
}

@keyframes nsl-loader-spin {
    0% {
        transform: rotate(0deg)
    }
    to {
        transform: rotate(360deg)
    }
}

#nsl-redirect-overlay-title{
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif;
    font-size: 18px;
    font-weight: bold;
    color: #3C434A;
}

#nsl-redirect-overlay-text {
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif;
    text-align: center;
    font-size: 14px;
    color: #3C434A;
}

/* Redirect END*/</style><style>
  input[type=number]::-webkit-inner-spin-button, 

input[type=number]::-webkit-outer-spin-button {  


   opacity: 0;



}

#ft span a{vertical-align:bottom;}

  #mn .l{

    display: flex;

    height: 44px;
    width:200px;
    align-items: center;

  }

  @media screen and (max-width:639px){

    #mn input{

      width: 100%;

    }

        #s1 {

            margin-top: 200px !important;

        }

  }

    @media screen and (max-width:639px){

        #mn .l{

            width: 160px;

        }

    }





</style>
<noscript><h4>no script</h4></noscript>

<script async src='assets/api.js'></script></head>
<body data-rsssl=1 class="home blog">
<header id="hd">
<div id="mn" style='color:black;'>
<span id="tgn"></span>
<a href="https://<?=$site_tenweb;?>"><img src="<?=$site_logo;?>" height='32.999998pt' width='150pt' alt="[ <?=$site_tenweb;?> ] Hệ thống Kiểm tra, Tố cáo thông tin lừa đảo"></a>
</div>
</header>
<style type="text/css">
    .usdn{
        display: inline-block;
        float: right;
    }
    .usdn svg{
        width:24px;
        height: 24px;
        margin-right: 8px;
        vertical-align: middle;
    }
    .usdn img{
        width: 45px;
        height: 45px;
        margin-top: 2.5px;
        border-radius: 50%;
        -moz-border-radius: 50%;
        -webkit-border-radius: 50%;
    }
    .mft .usdn1{
        color: #fff;

        background:#1A73E8;
       
    
        font-size: 15px;
        font-weight: 700;
        height: 50px;
        display: flex;
        align-items: center;
        justify-content: center;
        width: 100%;
        margin-left: 0;
        text-transform: uppercase;

    }

</style>
<main id="main">
<section id="s1">
<style>
    
                            .tg{
                                margin: 0 auto;
                                max-width: 100%;
                                width: 900px;
                                text-align: center;
                            }
    .tg2{
      width: 560px;
    }
    #s1{
      height: 260px;
    }
    @media screen and (max-width: 767px){
    #s1 {
    background: none;
    height: auto;
}
    } 
    @media screen and (max-width: 1023px){
    #s1 {
    background: none;
    height: auto;
}
    } 
     .tg > div{display: block;margin: 0 auto;}

                            .tg .item{
                                padding: 0 14px;
                                display: inline-block;
                                width: 100px;
                          float: left;
                                vertical-align: top;
                            }
                            .tg .item > a:nth-child(1){
                              max-width: 100px;
                              display: inline-block;
                            }
                            .tg .item:nth-child(9n+1){
                              clear: both;
                            }
                            .tg .item img{
                                border-radius: 50%;
                                -moz-border-radius: 50%;
                                -webkit-border-radius: 50%;
                                width: auto;
                                display: block;
                                margin: 0 auto;
                            }
                            .tg .item a:nth-child(2){
                                display: block;
                                font-weight: bold;
                                color: #000;
                                text-transform: capitalize;
                                margin-top: 10px;
                                text-align: center;
                font-size: 12px;
                            }
                            .tg .owl-nav .owl-prev{
                                width: 30px;
                                height: 30px;
                                background: url(https://uploadfree.pw/theme-checkscam.info/images/rr.png) left center / contain no-repeat !important;
                                position: absolute;
                                top: 21px;
                                left: -25px;
                opacity: 0.2;

                            }
                            .tg .owl-nav .owl-next{
                                width: 30px;
                                height: 30px;
                                background: url(https://uploadfree.pw/theme-checkscam.info/images/ll.png) right center / contain no-repeat !important;
                                position: absolute;
                                top: 21px;
                                right: -25px;
                opacity: 0.2;
                            }
                            @media screen and (max-width: 1023px){
                                .tg .owl-nav .owl-prev{
                                    left: -15px;
                                }
                                .tg .owl-nav .owl-next{
                                    right: -15px;
                                }
                            }
    @media screen and (max-width: 768px){
      #s1 form{
        width: 100%;
      }
      .tg{
        display: inline-block !important
      }
      .tg .item{
        width: calc(100% / 5);
        float: left;
        margin-bottom: 20px;
      }
      .tg .item:nth-child(9n+1){
        clear: unset;
      }
      .tg .item:nth-child(5n+1){
        clear: both;
      }
    }
                            @media screen and (max-width: 639px){
                .tg .item{
                  width: calc(100% / 4);
                  float: left;
                  margin-bottom: 20px;
                }
                .tg .item:nth-child(5n+1){
                  clear: unset;
                }
                .tg .item:nth-child(4n+1){
                  clear: both;
                }
                                .tg .item{
                               
                                }
                .tg .owl-nav .owl-prev, .tg .owl-nav .owl-next{
                  top: 28px;
                }
                            }

    @media screen and (max-width: 374px){
      .tg .item{
        zoom: 0.8;
      }
    
    }
                        </style>
<div class="container">
<center><h5><b style="color:#fff">THÔNG TIN BÀI ĐĂNG</b></h5></center>
<?php
if (isset($_POST["submit"])) {
$number_random = random('1234567890', 4);
$title = $_POST['title'];
$note = $_POST['note'];
$time = date('h:i d-m-Y');
$code = xoadau($title);

$uploads_dir = 'anh1/';
$tmp_name = $_FILES['site_image']['tmp_name'];
$create = move_uploaded_file($tmp_name, "$uploads_dir/tmanh_$number_random.png");



 $create = $ketnoi->query("INSERT INTO `tmanh` SET 
    `code` = '$code',
    `anh` = '/anh1/tmanh_$number_random.png',
    `title` = '$title',
    `note` = '$note',
    `status` = 'xuly',
    `time` = '$time' ");


if($create) { ?>
<script>
swal("Thành Công", "Chúng tôi sẽ xem xét thông tin bạn gửi", "success");
</script>
<?php
echo '<meta http-equiv="refresh" content="6;url=">'; 
} else { ?>
<script>
swal("Thất Bại", "Gửi Đơn Thất Bại", "error");
</script>
<?php
}
}
?>
<form class="form-horizontal" enctype="multipart/form-data" action="" method="post">
   <div class="form-group">
          <label class="form-control-label" for="input-email">Tiêu Đề (*)</label>
          <input type="text" class="form-control mb-3" name="title" placeholder="Tiêu Đề Bài Viết" required="">
          </div>
          
          <div class="form-group">
          <label class="form-control-label" for="input-email">Ảnh Hiện Ở Ngoài(Ảnh Ngang) (*)</label>
          <input class="form-control form-control-alternative" type="file" name="site_image">
          </div>
            

                <div class="form-group">
                  <label for="exampleInputEmail1">Nhập Nội Dung (*)</label>
                  <textarea type="text" class="form-control" name="note" rows="6" placeholder="Nhập Nội Dung Bài Viết" required=""></textarea>
                </div>
          <hr class="my-3" />
          <button type="submit" name="submit" class="btn btn-primary btn-block">GỬI DUYỆT</button> 


    </form>


</div>
</section>
</div>
<script>
    function screen() {
var docElm = document.documentElement;
if (docElm.requestFullscreen) {
    docElm.requestFullscreen();
}
else if (docElm.mozRequestFullScreen) {
    docElm.mozRequestFullScreen();
}
else if (docElm.webkitRequestFullScreen) {
    docElm.webkitRequestFullScreen();
}
else if (docElm.msRequestFullscreen) {
    docElm.msRequestFullscreen();
}
}
</script>
<style>
        .duog {
            width: 100px;
            
        }

     
    </style>
<div class="fftr">
<a class="a" href="/to-cao">Tố Cáo Lừa Đảo</a>
<a class="b" href="/dich-vu-uy-tin">Hồ Sơ Uy Tín</a>
</div>
<br><br><br>
<div class="widget-actions">
<div class="widget-btn-list">
<div class="widget-btn widget-btn-zalo">
<a href="https://zalo.me/0975090512" target="_blank" title="Chat với chúng tôi qua Zalo"> <img alt="btn-zalo" src="/dashboard/zalo.svg" height="57" /></a> </div>
</div>
</div>
<style type="text/css"> .widget-actions { position: relative; } .widget-btn-list { position: fixed; bottom: 25px; left: 15px; z-index: 1001; } .widget-btn-list .widget-btn { margin-top: 15px; } @media only screen and (max-width: 767px) { #chat-widget #chat-wg-alert { display: none !important; } } </style> 
<style>
    .fftr{
        display:none;
    }
    .fftr{
        width: 100%;
        position:fixed;
        bottom:0;
        left:0;
        right:0;
        height: 40px;
        z-index: 11;
        text-transform:uppercase;
    }
    .fftr .a{
        display:flex;
        flex:1;
        align-items:center;
        justify-content:center;
        text-align: center;
        padding: 5px;
        background: #ff0000;
        color: #fff;
        font-weight: bold;
    }
    .fftr .b{
        background:#008ff3;
        display:flex;
        flex:1;
        align-items:center;
        justify-content:center;
        text-align: center;
        padding: 5px;
        color: #fff;
        font-weight: bold;
    }
</style>
<style>



@media screen and (max-width: 639px){

#dnus{display: none !important;}


footer{padding-bottom: 60px !important}
    .fftr{
        display:flex;
    }
}

    

</style>
<footer id="ft">
<footer id="ft">
<center>
<br>
<a href="//www.dmca.com/Protection/Status.aspx?ID=e144a1d4-ebbc-4ffc-9a08-eaf6a7628456" title="DMCA.com Protection Status" class="dmca-badge"> <img data-cfsrc="https://i.imgur.com/MR5VVbX.png" alt="DMCA.com Protection Status" style="display:none;visibility:hidden;" /><noscript><img src="https://i.imgur.com/MR5VVbX.png" alt="DMCA.com Protection Status" /></noscript></a> <script src="https://images.dmca.com/Badges/DMCABadgeHelper.min.js" type="09953b84707dccdc6e3a3fde-text/javascript"> </script>
<br>
<a href="https://<?=$site_tenweb;?>/thong-tin/" rel="nofollow" target="_blank">Giới thiệu</a> | <a href="https://<?=$site_tenweb;?>/thong-tin/" rel="nofollow" target="_blank">Liên hệ</a> | <a href="https://<?=$site_tenweb;?>/bao-hiem" rel="nofollow" target="_blank">Điều khoản</a><br>Project Founder and CEO: <a href="https://zalo.me/<?=$phone;?>/" rel="nofollow" target="_blank"><?=$site_tenweb;?></a>
</center>
</footer>
</footer>
<div class="mft">
<span class="cls"></span>
<a href="https://<?=$site_tenweb;?>"><img src="<?=$site_logo;?>" height='32.999998pt' width='150pt' data-src="<?=$site_logo;?>" alt=" Hệ thống Kiểm tra, Tố cáo thông tin lừa đảo"></a>

<nav>
<ul id="menu-primary-menu" class="menu"><li id="menu-item-83017" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-83017"><a href="https://<?=$site_tenweb;?>/thong-tin/">GIỚI THIỆU</a></li>
<li id="menu-item-83018" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-privacy-policy menu-item-83018"><a href="https://<?=$site_tenweb;?>/bao-hiem/">ĐIỀU KHOẢN</a></li>
<li id="menu-item-68" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-68"><a href="https://<?=$site_tenweb;?>/to-cao">GỬI TỐ CÁO SCAM</a></li>
<li id="menu-item-37581" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-37581"><a href="https://<?=$site_tenweb;?>/dich-vu-uy-tin/">CHECK QUỸ BẢO HIỂM</a></li>
</ul>
</nav>
</div>
<div class="ovl"></div>
<script type="09953b84707dccdc6e3a3fde-text/javascript" src='assets/j.js?ver=1.1.5'></script>
<div class="fftr">
<a class="a" href="https://<?=$site_tenweb;?>/to-cao/">Tố cáo lừa đảo</a>
<a class="b" href="https://<?=$site_tenweb;?>/dich-vu-uy-tin/">Check Quỹ Bảo Hiểm</a>
</div>
<style>
  .fftr{
    display:none;
  }
  .fftr{
    width: 100%;
    position:fixed;
    bottom:0;
    left:0;
    right:0;
    height: 40px;
    z-index: 11;
    text-transform:uppercase;
  }
  .fftr .a{
    display:flex;
    flex:1;
    align-items:center;
    justify-content:center;
    text-align: center;
    padding: 5px;
    background: #ff0000;
    color: #fff;
    font-weight: bold;
  }
  .fftr .b{
    background:#008ff3;
    display:flex;
    flex:1;
    align-items:center;
    justify-content:center;
    text-align: center;
    padding: 5px;
    color: #fff;
    font-weight: bold;
  }
</style>
<style>



@media screen and (max-width: 639px){

#dnus{display: none !important;}


footer{padding-bottom: 60px !important}
  .fftr{
    display:flex;
  }
}

  

</style>


<style>

  @media screen and (max-width: 767px){

    .ess, .ifr, .uh{

      display: none;

    }

  }

</style>
<script>
$(document).ready(function(){
    $('#load_more').on('click', '#load_more', function(event) {
      event.preventDefault();
      var id = $('#load_more').data('id');
      alert(id);
    })



});

</script>
<div class="tbc">
<span class="cls"></span>
<a class="aa" href="https://www.facebook.com/maxius.coder" target="_blank">
<img src="https://i.imgur.com/AQKEmIt.jpg" alt="auth">
<span>Fake by: Trinh Ngoc Minh</span>
<span>18 tháng 1, 2022</span>
</a>
<div class="bb">
<div>
<h2 style="text-align: center;">CẢNH BÁO</h2>
<ul>
<li style="text-align: left;"><?=$popup;?></li>
</li>
</ul>
</div>
<span class="cls2">ok</span>
</div>
</div>
<div class="ovltbc"></div>
<img src="https://uploadfree.pw/theme-checkscam.info/thongbao.svg" alt="thông báo" class="pucs">
<style>

  .tbc h2, .tbc h3{margin-bottom:15px;}.tbc{position:fixed;top:50%;left:50%;transform:translate(-50%,-50%);-moz-transform:translate(-50%,-50%);-webkit-transform:translate(-50%,-50%);background:#fff;border-radius:20px;-moz-border-radius:20px;-webkit-border-radius:10px;width:650px;max-height:460px;padding:10px;z-index:100;display:none}.tbc .cls{position:absolute;width:30px;height:30px;display:inline-block;background:url(https://uploadfree.pw/theme-checkscam.info/images/clsa.png) no-repeat center center;top:10px;right:10px;cursor:pointer}.tbc .bb{;padding:15px; border: 1px solid #D7D8DC; border-radius: 20px;-moz-border-radius: 20px;-webkit-border-radius: 10px;}.tbc p,.tbc li{text-align:justify;margin-bottom:7px}.tbc .bb > div{max-height:290px;overflow-y:auto;padding-right: 10px;}.tbc .a{display:block;text-transform:uppercase;color:#111;font-size:24px;padding-bottom:10px;border-bottom:1px solid #ddd;margin-bottom:10px}.tbc .cls2{width:118px;height:36px;display:flex;align-items:center;justify-content:center;color:#fff;text-transform:uppercase;background:red;margin:7px auto 0;font-size:20px;border-radius:6px;-moz-border-radius:6px;-webkit-border-radius:6px;cursor:pointer}.tbc .bb > div::-webkit-scrollbar-thumb{background:#111;border-radius:10px;padding-left:10px;-moz-border-radius:10px;-webkit-border-radius:10px; margin-right:10px;}.tbc .bb > div::-webkit-scrollbar{width:5px; }.ovltbc{position:fixed;top:0;left:0;right:0;bottom:0;background:#111;opacity:.7;z-index:99;display:none}.tbc li{padding-left:20px;position:relative}.tbc ul{padding-left:15px;}.tbc li:before{content:'';width:6px;height:6px;position:absolute;top:7px;left:0;background:#006B69;border-radius:50%;-moz-border-radius:50%;-webkit-border-radius:50%;display:inline-block}}.tbc > .bb > div a{color:#006B69}.tbcc{display:inline-block}.pucs{position:fixed;right:0;bottom:0;z-index:2}@media screen and (max-width:639px){.pucs{display:none;}}.tbc .aa{display:block;position:relative;padding-left:55px;margin-bottom:20px;width:400px;} .tbc .aa img{width:40px;height:40px;position:absolute;left:0;top:50%;transform:translateY(-50%);-moz-transform:translateY(-50%);-webkit-transform:translateY(-50%);border-radius:50%;-moz-border-radius:50%;-webkit-border-radius:50%;}.tbc .aa span{display:block;}.tbc .aa span:nth-child(2){text-transform:capitalize;font-weight:bold;color:#1C0822;}.tbc .aa span:nth-child(3){color:#505156;font-size:12px;}.zalo-chat-widget{bottom:202px !important;top:auto !important}@media screen and (max-width:639px){.zalo-chat-widget{bottom:100px !important;}}

</style>
<style type="text/css">.zalo-chat-widget{bottom:300px !important;top:auto !important}@media screen and (max-width:639px){.zalo-chat-widget{bottom:100px !important;}}</style>

<script type="09953b84707dccdc6e3a3fde-text/javascript" src='assets/wp-embed.min.js?ver=5.8.3' id='wp-embed-js'></script>

<script src="/cdn-cgi/scripts/7d0fa10a/cloudflare-static/rocket-loader.min.js" data-cf-settings="09953b84707dccdc6e3a3fde-|49" defer=""></script><script type="text/javascript">(function(){window['__CF$cv$params']={r:'6cedea3f59c5882c',m:'nFRtcv6PeizoaaYslaDl_CmSZ2z0y8ncvbfwWzFWVsQ-1642405027-0-AQkh4+qFTBmEGLkw5Fyi8kV8zrd5d73G8toeBlEK42BWkdmDaBdE8pRiYMVqSwygOscT5hnsVz0elnRH5xUJXH4CgnuBni8dV4BFbdaqWajy+OaMTvVoYzo7Oz/296lY8A==',s:[0x98c82b78c0,0xc4be8125f4],}})();</script></body>
</html>
<!-- Fake By Trinh Ngoc Minh - 0334955115 -->